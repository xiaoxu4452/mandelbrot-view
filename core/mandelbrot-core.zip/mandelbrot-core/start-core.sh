#!/usr/bin/env bash
# MANDELBROT — start the local core and the static page.
set -e
cd "$(dirname "$0")"
command -v node >/dev/null 2>&1 || { echo "Node.js 18+ is required: https://nodejs.org"; exit 1; }

node server/render-server.mjs &
CORE=$!
node server/static-server.mjs &
PAGE=$!
trap 'kill $CORE $PAGE 2>/dev/null' EXIT

sleep 1
( command -v open >/dev/null && open http://127.0.0.1:8777/index.html ) \
  || ( command -v xdg-open >/dev/null && xdg-open http://127.0.0.1:8777/index.html ) \
  || echo "Open http://127.0.0.1:8777/index.html in your browser."

wait
