@echo off
chcp 65001 >nul
title MANDELBROT - local core
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo   Node.js was not found. Install Node.js 18+ from https://nodejs.org
  echo   then run this file again.
  echo.
  pause
  exit /b 1
)
echo   [1/2] render core  ->  http://127.0.0.1:8778
start "MANDELBROT render core" /min node "%~dp0server\render-server.mjs"
echo   [2/2] static page  ->  http://127.0.0.1:8777
start "MANDELBROT page" /min node "%~dp0server\static-server.mjs"
timeout /t 1 >nul
start "" http://127.0.0.1:8777/index.html
echo.
echo   Both servers are running in the background. Close those windows to stop them.
