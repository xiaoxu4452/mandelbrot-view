# MANDELBROT — local bundle

This archive contains the complete fractal observatory and its native render
core, so it runs offline with the kernel hosted outside the browser.

## Requirements
- Node.js 18 or newer (https://nodejs.org)

## Start
- **Windows** — double-click `start-core.bat`
- **macOS / Linux** — `bash start-core.sh`

The launcher starts two local servers and opens the page:

| service | address | purpose |
| --- | --- | --- |
| render core | http://127.0.0.1:8778 | worker-thread pool running the C++/WASM kernel |
| static page | http://127.0.0.1:8777 | serves this bundle over HTTP (required by ES modules) |

Both bind to the loopback interface only and are unreachable from the network.

## Why the core cannot be used from the hosted page
GitHub Pages serves over HTTPS, and browsers refuse to let an HTTPS page call
http://127.0.0.1 (mixed content). Run this bundle locally to use the core; the
hosted build keeps using the in-browser WebAssembly kernel, which is the same
code path.
